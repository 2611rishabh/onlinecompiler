#include<iostream>
using namespace std;
int main(){
int a = 5;
for(int i=1;i<=10;i++){
int x = a*1;
cout<< x<< " ";
}
return 0;
}