#include<iostream>
using namespace std;
int main(){
int a = 5;
for(int i=1;i<=10;i++){
int x = a*i;
cout<< x<< " ";
}
return 0;
}